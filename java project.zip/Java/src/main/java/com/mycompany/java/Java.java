/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.java;

/**
 *
 * @author hp
 */
public class Java {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
